=== Motivational phrases | Jomalat Angizashi ===
Contributors: clarotm
Donate link:
Tags: Sentence, motivational, motivational sentences, shortcode, WordPress, Clarotm
Requires at least: 6.0
Tested up to: 6.0
Stable tag: 1
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin is a shortcode for displaying motivational quotes or your favorite quotes on your website

== Description ==

To add text, open the jomalat.txt file and write one sentence in each line

Github this project : [Visit](https://github.com/Amirrezaheydari81/Motivational-phrases)

== Frequently Asked Questions ==

= Does the plugin speed up the site? =

No, because this plugin is optimally developed

== Screenshots ==


== Changelog ==

= 1.0 =
* A Start plugin development

== Upgrade Notice ==

= 1.0 =